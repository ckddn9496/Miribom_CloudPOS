package com.example.cloudpos.connections;

public interface MiribomInfo {
    /*  setting server ip address   */
    String ipAddress = "http://54.180.145.179:3000/tablet";   //  AWS server
//    String ipAddress = "http://192.168.43.144:3000/tablet";   //  Local DEV-server

}
